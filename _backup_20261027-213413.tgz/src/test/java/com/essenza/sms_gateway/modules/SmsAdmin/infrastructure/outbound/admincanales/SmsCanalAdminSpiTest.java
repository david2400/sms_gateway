package com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.admincanales;

import com.essenza.admin_canales.domain.model.Cuenta;
import com.essenza.admin_canales.domain.model.PlanEfectivo;
import com.essenza.sms_gateway.modules.SmsCore.application.input.RefreshSmsRoutingUseCase;
import com.essenza.sms_gateway.modules.SmsCore.domain.model.MessageType;
import com.essenza.sms_gateway.modules.SmsCore.domain.model.RoutePlan;
import com.essenza.sms_gateway.modules.SmsCore.domain.ports.RoutingPolicyPort;
import com.essenza.sms_gateway.modules.SmsCore.domain.ports.SecretCipherPort;
import com.essenza.sms_gateway.modules.SmsCore.domain.ports.SmsSenderPort;
import org.junit.jupiter.api.Test;
import org.springframework.mock.env.MockEnvironment;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class SmsCanalAdminSpiTest {

    private final SecretCipherPort cipher = mock(SecretCipherPort.class);
    private final RefreshSmsRoutingUseCase refresh = mock(RefreshSmsRoutingUseCase.class);
    private final RoutingPolicyPort routing = mock(RoutingPolicyPort.class);
    private final SmsSenderPort inalambria = mock(SmsSenderPort.class);
    private final MockEnvironment env = new MockEnvironment().withProperty("INALAMBRIA_PASSWORD", "x").withProperty("USR", "u");

    private SmsCanalAdminSpi spi() {
        when(inalambria.providerCode()).thenReturn("inalambria");
        return new SmsCanalAdminSpi(List.of(inalambria), cipher, env, refresh, routing);
    }

    @Test
    void implementadosEnMayusculasYRefrescaRouting() {
        SmsCanalAdminSpi spi = spi();
        assertEquals(Set.of("INALAMBRIA"), spi.proveedoresImplementados());
        spi.refrescarRouting();
        verify(refresh).refresh();
    }

    @Test
    void credencialesRequierenUsuarioYSecretoResoluble() {
        SmsCanalAdminSpi spi = spi();
        when(cipher.isConfigured()).thenReturn(true);
        when(cipher.decrypt("v1:ok")).thenReturn("plano");
        when(cipher.decrypt("v1:otra")).thenThrow(new IllegalArgumentException("otra llave"));
        assertTrue(spi.credencialDisponible(Cuenta.builder().usuario("u").claveCifrada("v1:ok").build()));
        assertFalse(spi.credencialDisponible(Cuenta.builder().usuario("u").claveCifrada("v1:otra").build()));
        assertTrue(spi.credencialDisponible(Cuenta.builder().usuario("env:USR").secretRef("INALAMBRIA_PASSWORD").build()));
        assertFalse(spi.credencialDisponible(Cuenta.builder().usuario("env:NO_EXISTE").secretRef("INALAMBRIA_PASSWORD").build()));
        assertFalse(spi.credencialDisponible(Cuenta.builder().secretRef("INALAMBRIA_PASSWORD").build()));
        assertEquals(Boolean.FALSE, spi.secretDefinido(Cuenta.builder().secretRef("NO_EXISTE").build()));
    }

    @Test
    void planEfectivoDeTipoDesconocidoYRutaVacia() {
        SmsCanalAdminSpi spi = spi();
        PlanEfectivo desconocido = spi.planEfectivo("NO_ES_ENUM", null, null, null);
        assertFalse(desconocido.isOk());
        assertEquals("TIPO_SIN_MOTOR", desconocido.getCodigoError());
        when(routing.resolve(any(), any())).thenReturn(RoutePlan.empty(null, MessageType.OTP));
        PlanEfectivo vacio = spi.planEfectivo("OTP", null, null, null);
        assertFalse(vacio.isOk());
        assertEquals("RUTA_NO_CONFIGURADA", vacio.getCodigoError());
    }
}
