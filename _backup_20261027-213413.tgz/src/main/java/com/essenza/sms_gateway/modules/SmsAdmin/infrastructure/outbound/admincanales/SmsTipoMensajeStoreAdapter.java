package com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.admincanales;

import com.essenza.admin_canales.domain.model.TipoMensaje;
import com.essenza.admin_canales.domain.ports.TipoMensajeStorePort;
import com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.persistence.entity.AdminTipoMensajeEntity;
import com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.persistence.repository.AdminTipoMensajeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/** SmsTipoMensaje para el núcleo admin-canales (canal SMS/WHATSAPP, otp, masivo; sin prioridad). */
@Component
@RequiredArgsConstructor
public class SmsTipoMensajeStoreAdapter implements TipoMensajeStorePort {

    private final AdminTipoMensajeRepository repository;

    @Override
    public List<TipoMensaje> findAll() {
        return repository.findAllByOrderByCodigoAsc().stream().map(SmsTipoMensajeStoreAdapter::toModel).collect(Collectors.toList());
    }

    @Override
    public Optional<TipoMensaje> findByCodigo(String codigo) {
        return repository.findByCodigo(codigo).map(SmsTipoMensajeStoreAdapter::toModel);
    }

    @Override
    public TipoMensaje save(TipoMensaje t) {
        AdminTipoMensajeEntity e = t.getId() == null ? new AdminTipoMensajeEntity() : repository.findById(t.getId()).orElseThrow();
        e.setCodigo(t.getCodigo());
        e.setDescripcion(t.getDescripcion());
        e.setCanal(t.getCanalMensaje());
        e.setOtp(Boolean.TRUE.equals(t.getOtp()));
        e.setMasivo(Boolean.TRUE.equals(t.getMasivo()));
        e.setEliminado(t.isEliminado());
        return toModel(repository.saveAndFlush(e));
    }

    @Override
    public void delete(String codigo) {
        repository.findByCodigo(codigo).ifPresent(e -> {
            repository.delete(e);
            repository.flush();
        });
    }

    static TipoMensaje toModel(AdminTipoMensajeEntity e) {
        return TipoMensaje.builder()
                .id(e.getIdSmsTipoMensaje()).codigo(e.getCodigo()).descripcion(e.getDescripcion())
                .canalMensaje(e.getCanal()).otp(e.getOtp()).masivo(e.getMasivo())
                .eliminado(e.isEliminado()).usrCrea(e.getUsrCrea()).usrMod(e.getUsrMod())
                .createdAt(e.getCreatedAt()).updatedAt(e.getUpdatedAt())
                .build();
    }
}
