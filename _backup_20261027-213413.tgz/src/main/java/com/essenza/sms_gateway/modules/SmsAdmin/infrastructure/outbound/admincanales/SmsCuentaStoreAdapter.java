package com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.admincanales;

import com.essenza.admin_canales.domain.model.Cuenta;
import com.essenza.admin_canales.domain.ports.CuentaStorePort;
import com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.persistence.entity.AdminCuentaEntity;
import com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.persistence.repository.AdminCuentaRepository;
import com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.persistence.repository.AdminProveedorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/** SmsCuenta para el núcleo admin-canales (la clave llega ya cifrada). */
@Component
@RequiredArgsConstructor
public class SmsCuentaStoreAdapter implements CuentaStorePort {

    private final AdminCuentaRepository repository;
    private final AdminProveedorRepository proveedores;

    @Override
    public List<Cuenta> findAll(String proveedor) {
        if (proveedor == null) {
            return repository.findAllByOrderByCodigoAsc().stream().map(SmsCuentaStoreAdapter::toModel).collect(Collectors.toList());
        }
        return proveedores.findByCodigo(proveedor)
                .map(p -> repository.findByProveedor_IdSmsProveedorOrderByCodigoAsc(p.getIdSmsProveedor()).stream()
                        .map(SmsCuentaStoreAdapter::toModel).collect(Collectors.toList()))
                .orElse(List.of());
    }

    @Override
    public Optional<Cuenta> findByCodigo(String codigo) {
        return repository.findByCodigo(codigo).map(SmsCuentaStoreAdapter::toModel);
    }

    @Override
    public Cuenta save(Cuenta c) {
        AdminCuentaEntity e = c.getId() == null ? new AdminCuentaEntity() : repository.findById(c.getId()).orElseThrow();
        e.setProveedor(proveedores.findByCodigo(c.getProveedor()).orElseThrow());
        e.setCodigo(c.getCodigo());
        e.setUsuario(c.getUsuario());
        e.setSecretRef(c.getSecretRef());
        e.setClaveCifrada(c.getClaveCifrada());
        e.setRemitente(c.getRemitente());
        e.setParametrosJson(ParametrosJson.mapToJson(c.getParametros()));
        e.setEliminado(c.isEliminado());
        Long id = repository.saveAndFlush(e).getIdSmsCuenta();
        return repository.findWithProveedorByIdSmsCuenta(id).map(SmsCuentaStoreAdapter::toModel).orElseThrow();
    }

    static Cuenta toModel(AdminCuentaEntity e) {
        return Cuenta.builder()
                .id(e.getIdSmsCuenta()).proveedor(e.getProveedor().getCodigo()).codigo(e.getCodigo())
                .usuario(e.getUsuario()).secretRef(e.getSecretRef()).claveCifrada(e.getClaveCifrada())
                .remitente(e.getRemitente()).parametros(ParametrosJson.jsonToMap(e.getParametrosJson(), e.getCodigo()))
                .eliminado(e.isEliminado()).usrCrea(e.getUsrCrea()).usrMod(e.getUsrMod())
                .createdAt(e.getCreatedAt()).updatedAt(e.getUpdatedAt())
                .build();
    }
}
