package com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.admincanales;

import com.essenza.admin_canales.domain.model.Canal;
import com.essenza.admin_canales.domain.model.CapacidadesCanal;
import com.essenza.admin_canales.domain.model.Cuenta;
import com.essenza.admin_canales.domain.model.Paso;
import com.essenza.admin_canales.domain.model.PlanEfectivo;
import com.essenza.admin_canales.domain.ports.CanalAdminSpi;
import com.essenza.sms_gateway.modules.SmsCore.application.input.RefreshSmsRoutingUseCase;
import com.essenza.sms_gateway.modules.SmsCore.domain.model.MessageType;
import com.essenza.sms_gateway.modules.SmsCore.domain.model.RoutePlan;
import com.essenza.sms_gateway.modules.SmsCore.domain.model.RouteStep;
import com.essenza.sms_gateway.modules.SmsCore.domain.ports.RoutingPolicyPort;
import com.essenza.sms_gateway.modules.SmsCore.domain.ports.SecretCipherPort;
import com.essenza.sms_gateway.modules.SmsCore.domain.ports.SmsSenderPort;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

/**
 * Lo propio de sms_gateway para el núcleo admin-canales: senders (SmsSenderPort), cifrado (SMS_CRYPTO_KEY),
 * variables de entorno de secret_ref, caché de routing de SmsCore y ruta efectiva con RoutingPolicyPort.
 */
@Slf4j
@Component
public class SmsCanalAdminSpi implements CanalAdminSpi {

    static final CapacidadesCanal CAPACIDADES = CapacidadesCanal.builder()
            .canal(Canal.SMS)
            .eliminarRuta(true)
            .eliminarTipoMensaje(true)
            .probarCuenta(false)
            .eliminarClave(false)
            .cambiarProveedorCuenta(true)
            .credencialObligatoria(true)
            .parametrosPlanos(true)
            .baseUrlHttp(true)
            .prioridadTipoMensaje(false)
            .otpTipoMensaje(true)
            .canalesMensaje(List.of("SMS", "WHATSAPP"))
            .rutaEfectivaConPreferencia(false)
            .maxEsperaMs(60000)
            .maxRemitente(20)
            .remitenteEmail(false)
            .defaultMaxIntentos(3)
            .defaultEsperaMs(500)
            .defaultConnectTimeoutMs(2000)
            .defaultReadTimeoutMs(5000)
            .defaultPrioridad(5)
            .build();

    private final Set<String> implementados;
    private final SecretCipherPort cipher;
    private final Environment environment;
    private final RefreshSmsRoutingUseCase refresh;
    private final RoutingPolicyPort routing;

    public SmsCanalAdminSpi(List<SmsSenderPort> senders, SecretCipherPort cipher, Environment environment,
                            RefreshSmsRoutingUseCase refresh, RoutingPolicyPort routing) {
        TreeSet<String> codigos = senders.stream()
                .map(s -> s.providerCode().toUpperCase(Locale.ROOT)).collect(Collectors.toCollection(TreeSet::new));
        this.implementados = Collections.unmodifiableSet(codigos);
        this.cipher = cipher;
        this.environment = environment;
        this.refresh = refresh;
        this.routing = routing;
    }

    @Override
    public CapacidadesCanal capacidades() {
        return CAPACIDADES;
    }

    @Override
    public Set<String> proveedoresImplementados() {
        return implementados;
    }

    @Override
    public boolean cifradoConfigurado() {
        return cipher.isConfigured();
    }

    @Override
    public String cifrar(String clavePlana) {
        return cipher.encrypt(clavePlana);
    }

    /** Usuario y secreto resolubles (igual que el motor: clave cifrada descifrable o variable de secret_ref). */
    @Override
    public boolean credencialDisponible(Cuenta c) {
        return usuarioDisponible(c.getUsuario()) && (claveDescifrable(c) || Boolean.TRUE.equals(secretDefinido(c)));
    }

    @Override
    public Boolean secretDefinido(Cuenta c) {
        return definida(c.getSecretRef());
    }

    @Override
    public void refrescarRouting() {
        refresh.refresh();
    }

    @Override
    public PlanEfectivo planEfectivo(String tipoMensaje, String proveedor, String proveedorPreferido, String cuenta) {
        Optional<MessageType> tipo = MessageType.fromCodigo(tipoMensaje);
        if (tipo.isEmpty()) {
            return PlanEfectivo.builder().ok(false).codigoError("TIPO_SIN_MOTOR")
                    .detalle("El motor de SMS no tiene el tipo " + tipoMensaje + " (MessageType)").build();
        }
        RoutePlan plan = routing.resolve(proveedor, tipo.get());
        List<RouteStep> steps = plan.getSteps() == null ? List.of() : plan.getSteps();
        List<Paso> pasos = steps.stream().map(s -> Paso.builder()
                .orden(s.getOrder()).cuenta(s.getAccount().getCode()).proveedor(s.getAccount().getProviderCode())
                .maxIntentos(s.getMaxAttempts()).esperaMs((int) s.getWaitMs()).build()).collect(Collectors.toList());
        return pasos.isEmpty()
                ? PlanEfectivo.builder().ok(false).codigoError("RUTA_NO_CONFIGURADA")
                    .detalle("No hay ruta activa con pasos activos (los envíos responderán 422)").build()
                : PlanEfectivo.builder().ok(true).pasos(pasos).build();
    }

    private boolean claveDescifrable(Cuenta c) {
        if (c.getClaveCifrada() == null || c.getClaveCifrada().isBlank() || !cipher.isConfigured()) {
            return false;
        }
        try {
            cipher.decrypt(c.getClaveCifrada());
            return true;
        } catch (RuntimeException e) {
            log.warn("[SMS-ADMIN] La clave de la cuenta {} no se puede descifrar con la llave actual", c.getCodigo());
            return false;
        }
    }

    private boolean usuarioDisponible(String usuario) {
        if (usuario == null || usuario.isBlank()) {
            return false;
        }
        String u = usuario.trim();
        return !u.regionMatches(true, 0, "env:", 0, 4) || definida(u.substring(4));
    }

    private boolean definida(String variable) {
        if (variable == null || variable.isBlank()) {
            return false;
        }
        String v = environment.getProperty(variable.trim());
        return v != null && !v.isBlank();
    }
}
