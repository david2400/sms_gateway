package com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.Instant;

/**
 * Auditoría de las entidades de administración (mismas columnas que
 * {@link com.essenza.sms_gateway.shared.common.domain.entity.AuditInfo}) pero <b>sin {@code @SoftDelete}</b>.
 * <p>
 * Las entidades de SmsCore siguen con {@code @SoftDelete} (el motor de envío nunca ve registros inactivos).
 * Administración necesita lo contrario:
 * <ul>
 *   <li>ver y reactivar registros inactivos ({@code eliminado} es una columna normal y actualizable);</li>
 *   <li>borrar físicamente filas de tablas de relación ({@code SmsProveedorServicio}, {@code SmsRutaPaso}) para no
 *       chocar con sus índices únicos al reemplazarlas;</li>
 *   <li>reactivar una ruta inactiva en lugar de fallar por {@code ux_sms_ruta}.</li>
 * </ul>
 * <b>eliminado = true ⇒ inactivo; false ⇒ activo.</b>
 */
@MappedSuperclass
@Getter
@Setter
public abstract class AdminAuditInfo {

    @Column(name = "eliminado", nullable = false)
    private boolean eliminado;

    @Column(name = "usr_crea", nullable = false, length = 50, updatable = false)
    private Integer usrCrea;

    @Column(name = "usr_mod", length = 50)
    private Integer usrMod;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private Instant createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at", insertable = false)
    private Instant updatedAt;

    @PrePersist
    public void prePersist() {
        if (this.usrCrea == null) {
            this.usrCrea = 1;
        }
    }

    @PreUpdate
    public void preUpdate() {
        this.usrMod = 1;
    }
}
