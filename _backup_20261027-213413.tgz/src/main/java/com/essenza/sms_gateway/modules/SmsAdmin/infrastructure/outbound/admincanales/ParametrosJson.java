package com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.admincanales;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.essenza.admin_canales.domain.exception.AdminCanalException;

import java.util.LinkedHashMap;
import java.util.Map;

/** Columna parametros_json (texto) ↔ mapa clave/valor. */
final class ParametrosJson {

    private static final ObjectMapper JSON = new ObjectMapper();
    private static final TypeReference<LinkedHashMap<String, Object>> MAPA = new TypeReference<>() { };

    private ParametrosJson() {
    }

    static Map<String, Object> jsonToMap(String json, String cuenta) {
        if (json == null || json.isBlank()) {
            return new LinkedHashMap<>();
        }
        try {
            return JSON.readValue(json, MAPA);
        } catch (Exception e) {
            Map<String, Object> invalido = new LinkedHashMap<>();
            invalido.put("_jsonInvalido", json);
            return invalido;
        }
    }

    static String mapToJson(Map<String, Object> parametros) {
        if (parametros == null || parametros.isEmpty()) {
            return null;
        }
        try {
            return JSON.writeValueAsString(parametros);
        } catch (Exception e) {
            throw AdminCanalException.invalido("parametros no se pudo convertir a JSON: " + e.getMessage());
        }
    }
}
