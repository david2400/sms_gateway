package com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.admincanales;

import com.essenza.admin_canales.domain.model.Paso;
import com.essenza.admin_canales.domain.model.Ruta;
import com.essenza.admin_canales.domain.ports.RutaStorePort;
import com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.persistence.entity.AdminProveedorEntity;
import com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.persistence.entity.AdminRutaEntity;
import com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.persistence.entity.AdminRutaPasoEntity;
import com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.persistence.repository.AdminCuentaRepository;
import com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.persistence.repository.AdminProveedorRepository;
import com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.persistence.repository.AdminRutaPasoRepository;
import com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.persistence.repository.AdminRutaRepository;
import com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.persistence.repository.AdminTipoMensajeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/** SmsRuta + SmsRutaPaso para el núcleo admin-canales (proveedor null = ruta central). */
@Component
@RequiredArgsConstructor
public class SmsRutaStoreAdapter implements RutaStorePort {

    private final AdminRutaRepository rutas;
    private final AdminRutaPasoRepository pasos;
    private final AdminProveedorRepository proveedores;
    private final AdminTipoMensajeRepository tipos;
    private final AdminCuentaRepository cuentas;

    @Override
    public List<Ruta> findAll() {
        return rutas.findAllByOrderByIdSmsRutaAsc().stream().map(this::toModel).collect(Collectors.toList());
    }

    @Override
    public Optional<Ruta> findById(Long id) {
        return rutas.findWithProveedorByIdSmsRuta(id).map(this::toModel);
    }

    @Override
    public Optional<Ruta> findFor(String proveedor, String tipoMensaje) {
        Long tipoId = tipos.findByCodigo(tipoMensaje).map(t -> t.getIdSmsTipoMensaje()).orElse(null);
        if (tipoId == null) {
            return Optional.empty();
        }
        if (proveedor == null) {
            return rutas.findFirstByProveedorIsNullAndTipoMensaje_IdSmsTipoMensaje(tipoId).map(this::toModel);
        }
        return proveedores.findByCodigo(proveedor)
                .flatMap(p -> rutas.findFirstByProveedor_IdSmsProveedorAndTipoMensaje_IdSmsTipoMensaje(p.getIdSmsProveedor(), tipoId))
                .map(this::toModel);
    }

    @Override
    public Ruta save(Ruta r) {
        AdminRutaEntity e = r.getId() == null ? new AdminRutaEntity() : rutas.findById(r.getId()).orElseThrow();
        AdminProveedorEntity proveedor = r.getProveedor() == null ? null : proveedores.findByCodigo(r.getProveedor()).orElseThrow();
        e.setProveedor(proveedor);
        e.setTipoMensaje(tipos.findByCodigo(r.getTipoMensaje()).orElseThrow());
        e.setEliminado(r.isEliminado());
        Long id = rutas.saveAndFlush(e).getIdSmsRuta();
        return findById(id).orElseThrow();
    }

    @Override
    public void reemplazarPasos(Long rutaId, List<Paso> nuevos) {
        pasos.deleteByRutaId(rutaId);
        List<AdminRutaPasoEntity> entities = nuevos.stream().map(p -> {
            AdminRutaPasoEntity e = new AdminRutaPasoEntity();
            e.setRuta(rutas.getReferenceById(rutaId));
            e.setOrden(p.getOrden());
            e.setCuenta(cuentas.findByCodigo(p.getCuenta()).orElseThrow());
            e.setMaxIntentos(p.getMaxIntentos());
            e.setEsperaMs(p.getEsperaMs());
            return e;
        }).collect(Collectors.toList());
        pasos.saveAllAndFlush(entities);
    }

    @Override
    public void delete(Long rutaId) {
        pasos.deleteByRutaId(rutaId);
        rutas.deleteById(rutaId);
        rutas.flush();
    }

    private Ruta toModel(AdminRutaEntity e) {
        List<Paso> ps = pasos.findByRuta_IdSmsRutaAndEliminadoFalseOrderByOrdenAsc(e.getIdSmsRuta()).stream()
                .map(p -> Paso.builder().orden(p.getOrden()).cuenta(p.getCuenta().getCodigo())
                        .proveedor(p.getCuenta().getProveedor().getCodigo())
                        .maxIntentos(p.getMaxIntentos()).esperaMs(p.getEsperaMs()).build())
                .collect(Collectors.toList());
        return Ruta.builder()
                .id(e.getIdSmsRuta())
                .proveedor(e.getProveedor() == null ? null : e.getProveedor().getCodigo())
                .tipoMensaje(e.getTipoMensaje().getCodigo())
                .pasos(ps)
                .eliminado(e.isEliminado()).usrCrea(e.getUsrCrea()).usrMod(e.getUsrMod())
                .createdAt(e.getCreatedAt()).updatedAt(e.getUpdatedAt())
                .build();
    }
}
