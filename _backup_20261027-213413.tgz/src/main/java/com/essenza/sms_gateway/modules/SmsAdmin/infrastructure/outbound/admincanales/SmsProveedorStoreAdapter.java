package com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.admincanales;

import com.essenza.admin_canales.domain.exception.AdminCanalException;
import com.essenza.admin_canales.domain.model.Proveedor;
import com.essenza.admin_canales.domain.ports.ProveedorStorePort;
import com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.persistence.entity.AdminProveedorEntity;
import com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.persistence.entity.AdminProveedorServicioEntity;
import com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.persistence.repository.AdminProveedorRepository;
import com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.persistence.repository.AdminProveedorServicioRepository;
import com.essenza.sms_gateway.modules.SmsAdmin.infrastructure.outbound.persistence.repository.AdminTipoMensajeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/** SmsProveedor + SmsProveedorServicio para el núcleo admin-canales. */
@Component
@RequiredArgsConstructor
public class SmsProveedorStoreAdapter implements ProveedorStorePort {

    private final AdminProveedorRepository repository;
    private final AdminProveedorServicioRepository servicios;
    private final AdminTipoMensajeRepository tipos;

    @Override
    public List<Proveedor> findAll() {
        return repository.findAllByOrderByCodigoAsc().stream().map(SmsProveedorStoreAdapter::toModel).collect(Collectors.toList());
    }

    @Override
    public Optional<Proveedor> findByCodigo(String codigo) {
        return repository.findByCodigo(codigo).map(SmsProveedorStoreAdapter::toModel);
    }

    @Override
    public Proveedor save(Proveedor p) {
        AdminProveedorEntity e = p.getId() == null ? new AdminProveedorEntity() : repository.findById(p.getId()).orElseThrow();
        e.setCodigo(p.getCodigo());
        e.setNombre(p.getNombre());
        e.setBaseUrl(p.getBaseUrl());
        e.setConnectTimeoutMs(p.getConnectTimeoutMs());
        e.setReadTimeoutMs(p.getReadTimeoutMs());
        e.setEliminado(p.isEliminado());
        return toModel(repository.saveAndFlush(e));
    }

    @Override
    public List<String> servicios(String proveedor) {
        return repository.findByCodigo(proveedor)
                .map(p -> servicios.findByProveedor_IdSmsProveedorAndEliminadoFalseOrderByTipoMensaje_CodigoAsc(p.getIdSmsProveedor()).stream()
                        .map(s -> s.getTipoMensaje().getCodigo()).collect(Collectors.toList()))
                .orElse(List.of());
    }

    @Override
    public void reemplazarServicios(String proveedor, Collection<String> tiposMensaje) {
        AdminProveedorEntity p = repository.findByCodigo(proveedor).orElseThrow();
        servicios.deleteByProveedorId(p.getIdSmsProveedor());
        List<AdminProveedorServicioEntity> nuevos = tiposMensaje.stream().map(codigo -> {
            AdminProveedorServicioEntity s = new AdminProveedorServicioEntity();
            s.setProveedor(repository.getReferenceById(p.getIdSmsProveedor()));
            s.setTipoMensaje(tipos.findByCodigo(codigo).orElseThrow(() -> AdminCanalException.invalido("No existe el tipo de mensaje " + codigo)));
            return s;
        }).collect(Collectors.toList());
        servicios.saveAllAndFlush(nuevos);
    }

    static Proveedor toModel(AdminProveedorEntity e) {
        return Proveedor.builder()
                .id(e.getIdSmsProveedor()).codigo(e.getCodigo()).nombre(e.getNombre()).baseUrl(e.getBaseUrl())
                .connectTimeoutMs(e.getConnectTimeoutMs()).readTimeoutMs(e.getReadTimeoutMs())
                .eliminado(e.isEliminado()).usrCrea(e.getUsrCrea()).usrMod(e.getUsrMod())
                .createdAt(e.getCreatedAt()).updatedAt(e.getUpdatedAt())
                .build();
    }
}
